
client_script "@np-errorlog/client/cl_errorlog.lua"

client_script "client.lua"
server_script "server.lua"


exports {
	'getTax'
} 
